import discord
import os
import aiohttp
import asyncio
import io
from dotenv import load_dotenv
from datetime import datetime, timedelta
from flask import Flask
from threading import Thread

# Load .env variables
load_dotenv()
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
HF_API_TOKEN = os.getenv("HF_API_TOKEN")
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")

# Discord setup
intents = discord.Intents.default()
intents.message_content = True
client = discord.Client(intents=intents)

# Flask keep-alive server
app = Flask('')

@app.route('/')
def home():
    return "I'm alive!"

def run():
    app.run(host='0.0.0.0', port=8080)

def keep_alive():
    t = Thread(target=run)
    t.start()

keep_alive()

# Chat memory
chat_history = [{
    "role": "system",
    "content": (
        "You are a Discord bot created by R1zzler.\n"
        "You MUST follow Discord's Terms of Service. Do not generate NSFW content.\n"
        "This bot resets memory every 2 hours."
    )
}]
last_command_time = datetime.utcnow()
MEMORY_DURATION = timedelta(hours=2)

def reset_chat():
    global chat_history
    chat_history = [chat_history[0]]

async def memory_watchdog():
    global last_command_time
    while True:
        await asyncio.sleep(60)
        if datetime.utcnow() - last_command_time > MEMORY_DURATION:
            reset_chat()
            last_command_time = datetime.utcnow()
            print("🧹 Chat memory reset")

# OpenRouter (chat)
async def generate_reply(messages):
    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": "deepseek/deepseek-chat-v3-0324:free",
        "messages": messages,
        "max_tokens": 1000
    }
    async with aiohttp.ClientSession() as session:
        async with session.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=payload) as resp:
            if resp.status != 200:
                error = await resp.text()
                raise Exception(f"❌ Chat error {resp.status}: {error}")
            return await resp.json()

# HuggingFace (image)
async def generate_image(prompt):
    url = "https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-xl-base-1.0"
    headers = {
        "Authorization": f"Bearer {HF_API_TOKEN}",
        "Content-Type": "application/json"
    }
    payload = {"inputs": prompt}
    async with aiohttp.ClientSession() as session:
        async with session.post(url, headers=headers, json=payload) as resp:
            if resp.status != 200:
                error = await resp.text()
                raise Exception(f"❌ Image error {resp.status}: {error}")
            return await resp.read()

@client.event
async def on_ready():
    print(f"✅ Logged in as {client.user}")
    asyncio.create_task(memory_watchdog())

@client.event
async def on_message(message):
    global last_command_time
    if message.author == client.user:
        return

    if message.content.startswith("\\ai.create.image"):
        prompt = message.content[len("\\ai.create.image"):].strip()
        if not prompt:
            await message.channel.send("⚠️ Provide a prompt after the command.")
            return
        await message.channel.send("🎨 Generating image...")
        try:
            image_bytes = await generate_image(prompt)
            await message.channel.send(file=discord.File(fp=io.BytesIO(image_bytes), filename="image.png"))
        except Exception as e:
            await message.channel.send(str(e))

    elif message.content.startswith("\\"):
        prompt = message.content[1:].strip()
        last_command_time = datetime.utcnow()
        chat_history.append({"role": "user", "content": f"{message.author.display_name}: {prompt}"})
        try:
            data = await generate_reply(chat_history)
            reply = data['choices'][0]['message']['content']
            chat_history.append({"role": "assistant", "content": reply})

            # Split into chunks if reply is too long
            for chunk in [reply[i:i+2000] for i in range(0, len(reply), 2000)]:
                await message.channel.send(chunk)

        except Exception as e:
            await message.channel.send(str(e))

client.run(DISCORD_TOKEN)